from __future__ import annotations

import numpy as np
import tifffile

# Optional lazy-loading stack (recommended for very large OME-TIFFs)
try:  # pragma: no cover
    import dask.array as da  # type: ignore
    import zarr  # type: ignore
except Exception:  # pragma: no cover
    da = None
    zarr = None

# ome-types is nice-to-have, but keep this module usable without it.
try:
    from ome_types import from_xml  # type: ignore
except Exception:  # pragma: no cover
    from_xml = None

import xml.etree.ElementTree as ET


def _normalize_to_yxc(arr: np.ndarray) -> np.ndarray:
    """
    Canonicalize to (Y, X, C) for common microscopy TIFF layouts:
      - (C, Y, X) -> (Y, X, C)
      - (Y, X, C) -> (Y, X, C)
    """
    if arr.ndim != 3:
        raise ValueError(f"Expected 3D array. Got shape={arr.shape}")

    # Heuristic: treat first axis as channel if small.
    if arr.shape[0] <= 32 and arr.shape[1] > 64 and arr.shape[2] > 64:
        arr = np.moveaxis(arr, 0, -1)  # (C,Y,X)->(Y,X,C)

    if not (arr.shape[0] > 64 and arr.shape[1] > 64):
        raise ValueError(f"Unexpected shape after normalization: {arr.shape}")

    return arr


def _channel_names_from_ome(ome_xml: str, n_channels: int) -> list[str] | None:
    if not ome_xml:
        return None

    # First try ome-types (if available)
    if from_xml is not None:
        try:
            ome = from_xml(ome_xml)
            # Most OME-TIFFs store channels under the first Image/Pixels.
            img0 = ome.images[0] if ome.images else None
            px = img0.pixels if img0 else None
            if not px or not px.channels:
                return None

            names: list[str] = []
            for ch in px.channels[:n_channels]:
                nm = (ch.name or "").strip()
                names.append(nm)

            if all(n == "" for n in names):
                return None
            return [n if n else "" for n in names]
        except Exception:
            pass

    # Fallback: parse OME-XML directly.
    try:
        root = ET.fromstring(ome_xml)
        # OME namespaces vary; strip them for matching.
        def _strip(tag: str) -> str:
            return tag.split("}", 1)[-1]

        channels: list[str] = []
        for el in root.iter():
            if _strip(el.tag) == "Channel":
                nm = (el.attrib.get("Name") or "").strip()
                channels.append(nm)
                if len(channels) >= n_channels:
                    break
        if not channels:
            return None
        if all(n == "" for n in channels):
            return None
        if len(channels) < n_channels:
            channels += [""] * (n_channels - len(channels))
        return channels[:n_channels]
    except Exception:
        return None


def _series_channel_axis(shape: tuple[int, ...], axes: str) -> int | None:
    """Infer which axis stores channels/samples for a TIFF series."""
    axes = (axes or "").upper()
    if len(shape) != 3:
        return None
    if axes:
        if "C" in axes:
            ax = int(axes.index("C"))
            if 0 <= ax < len(shape):
                return ax
        if "S" in axes:
            ax = int(axes.index("S"))
            if 0 <= ax < len(shape):
                return ax
    # Heuristic fallback matching _normalize_to_yxc
    if shape[0] <= 32 and shape[1] > 64 and shape[2] > 64:
        return 0
    return 2


def inspect_tiff_yxc(path: str) -> tuple[tuple[int, int, int], np.dtype, str, int]:
    """Return ``((Y, X, C), dtype, axes, channel_axis)`` without loading full pixel data."""
    with tifffile.TiffFile(path) as tf:
        series = tf.series[0]
        shape = tuple(int(x) for x in series.shape)
        dtype = np.dtype(series.dtype)
        axes = getattr(series, "axes", "") or ""

    ch_axis = _series_channel_axis(shape, axes)
    if len(shape) != 3 or ch_axis is None:
        raise ValueError(f"Expected 3D TIFF series. Got shape={shape} axes={axes!r} for {path}")

    if ch_axis == 0:
        y, x, c = int(shape[1]), int(shape[2]), int(shape[0])
    elif ch_axis == 2:
        y, x, c = int(shape[0]), int(shape[1]), int(shape[2])
    else:
        raise ValueError(f"Unsupported channel axis {ch_axis} for shape={shape} axes={axes!r} ({path})")

    return (y, x, c), dtype, axes, ch_axis


def load_single_channel_tiff_native(path: str, channel_index: int) -> np.ndarray:
    """Load one channel plane as ``(Y, X)`` preserving on-disk dtype.

    This avoids reading the full multichannel stack when the TIFF layout allows it:
      - for ``(C, Y, X)`` data, read just the selected page/channel when possible
      - for ``(Y, X, C)`` data, read the single multi-sample page and slice the channel

    If the TIFF layout is unusual, falls back to reading the full stack and slicing.
    """
    idx = int(channel_index)
    shp_yxc, _dtype, _axes, ch_axis = inspect_tiff_yxc(path)
    n_channels = int(shp_yxc[2])
    if idx < 0 or idx >= n_channels:
        raise IndexError(f"channel_index out of range: {channel_index} for {path}")

    with tifffile.TiffFile(path) as tf:
        series = tf.series[0]

        # Best case for CYX: one page per channel plane.
        if ch_axis == 0:
            try:
                page = series.pages[idx] if hasattr(series, "pages") else tf.pages[idx]
                arr = page.asarray()
                if getattr(arr, "ndim", None) == 2:
                    return np.asarray(arr)
            except Exception:
                pass

        # Best case for YXC: one page with interleaved samples. Read just that page.
        if ch_axis == 2:
            try:
                page = series.pages[0] if hasattr(series, "pages") and len(series.pages) else tf.pages[0]
                arr = page.asarray()
                arr = np.asarray(arr)
                if arr.ndim == 3 and int(arr.shape[2]) > idx:
                    return arr[..., idx]
            except Exception:
                pass

        # Conservative fallback for unusual layouts.
        arr = series.asarray()

    arr = np.asarray(arr)
    if arr.ndim != 3:
        raise ValueError(f"Expected 3D TIFF series. Got shape={arr.shape} for {path}")
    if ch_axis == 0:
        return arr[idx, :, :]
    if ch_axis == 2:
        return arr[:, :, idx]
    raise ValueError(f"Unsupported channel axis {ch_axis} for {path}")



class IncrementalOmeBigTiffWriter:
    """Incrementally write a (Y, X, C) image to an on-disk OME BigTIFF.

    This Stage 1 writer uses ``tifffile.memmap`` to back the output array with
    the TIFF file on disk, allowing callers to write one channel plane at a time
    without keeping the full merged output stack in RAM.

    Notes
    -----
    - Compression is intentionally disabled because memory-mapped incremental
      writes require an uncompressed layout.
    - Internally the TIFF is stored as (C, Y, X) with OME axes="CYX".
    """

    def __init__(self, path: str, shape_yxc: tuple[int, int, int], dtype: np.dtype, channel_names: list[str] | None = None):
        if len(shape_yxc) != 3:
            raise ValueError(f"Expected output shape (Y,X,C). Got {shape_yxc}")
        y, x, c = (int(shape_yxc[0]), int(shape_yxc[1]), int(shape_yxc[2]))
        if y <= 0 or x <= 0 or c <= 0:
            raise ValueError(f"Invalid output shape: {shape_yxc}")

        self.path = path
        self.shape_yxc = (y, x, c)
        self.dtype = np.dtype(dtype)
        if channel_names is None or len(channel_names) != c:
            channel_names = [f"Channel {i}" for i in range(c)]
        self.channel_names = list(channel_names)

        metadata = {
            "axes": "CYX",
            "Channel": {"Name": list(self.channel_names)},
        }

        self._mm = tifffile.memmap(
            self.path,
            shape=(c, y, x),
            dtype=self.dtype,
            photometric="minisblack",
            metadata=metadata,
            ome=True,
            bigtiff=True,
        )

    def write_channel(self, channel_index: int, plane_yx: np.ndarray) -> None:
        idx = int(channel_index)
        if idx < 0 or idx >= int(self.shape_yxc[2]):
            raise IndexError(f"channel_index out of range: {channel_index}")
        if plane_yx.ndim != 2:
            raise ValueError(f"Expected (Y,X) plane. Got shape={plane_yx.shape}")
        exp = (int(self.shape_yxc[0]), int(self.shape_yxc[1]))
        got = (int(plane_yx.shape[0]), int(plane_yx.shape[1]))
        if got != exp:
            raise ValueError(f"Plane shape mismatch. Expected {exp}, got {got}")
        self._mm[idx, :, :] = plane_yx.astype(self.dtype, copy=False)

    def flush(self) -> None:
        try:
            self._mm.flush()
        except Exception:
            pass

    def close(self) -> None:
        self.flush()
        try:
            del self._mm
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False


def save_ome_tiff_yxc(
    path: str,
    img_yxc: np.ndarray,
    channel_names: list[str] | None = None,
    *,
    compress: bool | int = True,
) -> None:
    """Save a (Y, X, C) array as an OME-TIFF with optional channel names.

    Notes
    -----
    tifffile's OME writer is most reliable when channels are stored in the
    leading dimension (C, Y, X) with axes="CYX".

    For larger images, classic TIFF uses 32-bit offsets and will fail once the
    file grows beyond ~4 GiB. In that case, we must write BigTIFF.

    To avoid OME-XML shape/axes mismatches in tifffile, we transpose to (C, Y, X)
    for writing.
    """
    if img_yxc.ndim != 3:
        raise ValueError(f"Expected (Y,X,C). Got shape={img_yxc.shape}")

    n_ch = int(img_yxc.shape[2])
    if channel_names is None or len(channel_names) != n_ch:
        channel_names = [f"Channel {i}" for i in range(n_ch)]

    # Write as (C, Y, X) to avoid OME-XML shape/axes mismatches in tifffile.
    img_cyx = np.moveaxis(img_yxc, 2, 0)

    metadata = {
        "axes": "CYX",
        "Channel": {"Name": list(channel_names)},
    }

    # Classic TIFF uses 32-bit offsets; BigTIFF is required once the written file
    # may exceed ~4 GiB. We conservatively decide based on the *uncompressed* size.
    try:
        bytes_per_px = int(np.dtype(img_cyx.dtype).itemsize)
        est_uncompressed = int(img_cyx.size) * bytes_per_px
    except Exception:
        est_uncompressed = 0

    bigtiff = bool(est_uncompressed >= (2**32 - 1))

    tifffile.imwrite(
        path,
        img_cyx,
        photometric="minisblack",
        metadata=metadata,
        ome=True,
        bigtiff=bigtiff,
        compression=("zlib" if compress is True else compress),
    )

def load_multichannel_tiff(path: str) -> tuple[np.ndarray, list[str]]:
    """
    Load a TIFF/OME-TIFF as (Y, X, C) float32 and return (img_yxc, channel_names).
    Attempts to read OME channel names via ome-types; falls back to "Channel i".
    """
    arr = tifffile.imread(path)
    arr = _normalize_to_yxc(arr)

    img = arr.astype(np.float32, copy=False)
    n_channels = img.shape[2]

    # Try OME metadata
    ch_names = None
    try:
        with tifffile.TiffFile(path) as tf:
            ome_xml = tf.ome_metadata
        ch_names = _channel_names_from_ome(ome_xml, n_channels)
    except Exception:
        ch_names = None

    if not ch_names or len(ch_names) != n_channels:
        ch_names = [f"Channel {i}" for i in range(n_channels)]
    else:
        # Replace blanks with Channel i
        ch_names = [
            (nm if nm and nm.strip() else f"Channel {i}")
            for i, nm in enumerate(ch_names)
        ]

    return img, ch_names


def load_multichannel_tiff_native(path: str) -> tuple[np.ndarray, list[str]]:
    """Load a TIFF/OME-TIFF as (Y, X, C) preserving the on-disk dtype.

    This is useful for preprocessing/registration steps where we want to keep the
    original integer dtype (e.g., uint16) and only use float32 as a transient
    compute type.
    """
    arr = tifffile.imread(path)
    arr = _normalize_to_yxc(arr)
    n_channels = int(arr.shape[2])

    # Try OME metadata (same logic as eager loader)
    ch_names = None
    try:
        with tifffile.TiffFile(path) as tf:
            ome_xml = tf.ome_metadata
        ch_names = _channel_names_from_ome(ome_xml, n_channels)
    except Exception:
        ch_names = None

    if not ch_names or len(ch_names) != n_channels:
        ch_names = [f"Channel {i}" for i in range(n_channels)]
    else:
        ch_names = [(nm if nm and nm.strip() else f"Channel {i}") for i, nm in enumerate(ch_names)]

    return arr, ch_names

def load_channel_names_only(path: str) -> list[str]:
    """Read OME channel names without reading full pixel data."""
    shp_yxc, _dtype, _axes, _channel_axis = inspect_tiff_yxc(path)
    n_channels = int(shp_yxc[2])

    with tifffile.TiffFile(path) as tf:
        ch_names = None
        try:
            ome_xml = tf.ome_metadata
            ch_names = _channel_names_from_ome(ome_xml, int(n_channels))
        except Exception:
            ch_names = None

    if not ch_names or len(ch_names) != int(n_channels):
        return [f"Channel {i}" for i in range(int(n_channels))]
    return [(nm if nm and nm.strip() else f"Channel {i}") for i, nm in enumerate(ch_names)]



def _normalize_to_cyx_lazy(arr) -> "da.Array":
    """Canonicalize a lazy array to (C, Y, X).

    Supported common microscopy TIFF layouts:
      - (C, Y, X) -> (C, Y, X)
      - (Y, X, C) -> (C, Y, X)
    """
    if da is None:
        raise RuntimeError(
            "Lazy loading requires dask and zarr. Install with: pip install dask[array] zarr"
        )
    if getattr(arr, "ndim", None) != 3:
        raise ValueError(f"Expected 3D array. Got shape={getattr(arr, 'shape', None)}")

    shp = tuple(int(x) for x in arr.shape)

    # Heuristic: treat first axis as channel if small.
    if shp[0] <= 32 and shp[1] > 64 and shp[2] > 64:
        return arr  # already (C,Y,X)

    # Otherwise, if last axis looks like channels, move it to front.
    if shp[2] <= 32 and shp[0] > 64 and shp[1] > 64:
        return da.moveaxis(arr, 2, 0)  # (Y,X,C)->(C,Y,X)

    # Fallback: assume (C,Y,X)
    return arr


def load_multichannel_tiff_lazy(path: str):
    """Lazy-load a TIFF/OME-TIFF and return (img_cyx, channel_names).

    The returned array is a **lazy** dask array backed by the TIFF on disk.
    No full image data are loaded into RAM until you compute slices.

    Notes
    -----
    - Requires `dask[array]` and `zarr`.
    - The returned image is canonicalized to (C, Y, X).
    """
    if da is None or zarr is None:
        raise RuntimeError(
            "Lazy loading requires dask and zarr. Install with: pip install dask[array] zarr"
        )

    # Use tifffile's Zarr interface for on-demand IO.
    store = tifffile.imread(path, aszarr=True)
    z = zarr.open(store, mode="r")
    arr = da.from_zarr(z)
    arr_cyx = _normalize_to_cyx_lazy(arr)

    # Channel names from OME metadata (same logic as eager loader)
    n_channels = int(arr_cyx.shape[0])
    ch_names = None
    try:
        with tifffile.TiffFile(path) as tf:
            ome_xml = tf.ome_metadata
        ch_names = _channel_names_from_ome(ome_xml, n_channels)
    except Exception:
        ch_names = None

    if not ch_names or len(ch_names) != n_channels:
        ch_names = [f"Channel {i}" for i in range(n_channels)]
    else:
        ch_names = [
            (nm if nm and nm.strip() else f"Channel {i}")
            for i, nm in enumerate(ch_names)
        ]

    return arr_cyx, ch_names
